﻿// testeimportacao.h: arquivo de inclusão para arquivos de inclusão padrão do sistema,
// ou arquivos de inclusão específicos a um projeto.

#pragma once

#include <iostream>

// TODO: Referencie os cabeçalhos adicionais de que seu programa precisa aqui.
